function [ answer ] = Tanh( x )
answer=0.5*tanh(x)+0.5;%tanh activation
end

