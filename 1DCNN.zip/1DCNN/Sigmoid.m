function [answer] = Sigmoid(x)
answer=1./(1+exp(-x));
end