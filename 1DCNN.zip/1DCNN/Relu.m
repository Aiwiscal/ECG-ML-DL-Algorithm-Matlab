function [ answer ] = Relu( x )
answer=max(0,x);%relu
end